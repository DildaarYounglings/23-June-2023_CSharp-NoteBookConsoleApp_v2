﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    class NotebookLogger
    {
        private NoteBookConsoleApp.NoteBook trackedNotebook;
    }
}
