﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    internal class MessageList : TexualMessage
    {
        private enum BulletType { Dashed, Numbered, Star };
        private BulletType bulletType;
        /// <summary>
        ///     is the override of the TexualMessage class method IPageable Input()
        /// </summary>
        /// <returns>
        ///     returns this which is the MessageList class
        /// </returns>
        public override IPageable Input()
        {
            Console.WriteLine("Please input your name");
            myData.author = Console.ReadLine();
            Console.WriteLine("Please input message title");
            myData.title = Console.ReadLine();
            Console.WriteLine("What type of bullet point would you like to use?");
            Console.WriteLine("Please enter the text dashed , number , or star");
            bool goodInput = false;
            while (!goodInput)
            {
                goodInput = true;
                switch(Console.ReadLine())
                {
                    case "dashed":
                        bulletType = BulletType.Dashed;
                        break;
                    case "numbered":
                        bulletType = BulletType.Numbered;
                        break;
                    case "star":
                        bulletType = BulletType.Star;
                        break;
                    default:
                        Console.WriteLine("Please enter the text dashed , number , or star");
                        goodInput = false;
                        break;
                }
            }
            Console.WriteLine("Start typing your list. everytime you press enter a new item will be made.");
            Console.WriteLine("Press enter with a blank list item to end your list input.");
            //write list
            bool finishedList = false;
            int i = 1;
            while (!finishedList)
            {
                string input = Console.ReadLine();
                //if nothing
                if (input == "")
                {
                    finishedList = true;
                }
                else
                {
                    switch (bulletType)
                    {
                        case BulletType.Dashed:
                            message += $"- {input} \n";
                            break;

                        case BulletType.Numbered:
                            message += $"{i}. {input} \n";
                            ++i;
                            break;

                        case BulletType.Star:
                            message += $"* {input} \n";
                            break;
                    }
                }
            }
            return this;
        }
    }
}
