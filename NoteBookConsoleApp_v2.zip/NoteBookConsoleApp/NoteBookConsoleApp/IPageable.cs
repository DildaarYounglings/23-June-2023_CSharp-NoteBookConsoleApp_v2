﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    public struct PageData
    {
        public string title;
        public string author;
    }
    public interface IPageable
    {
        // cant declare a field in interface thus using a struct or class using the set data and get data attributes or actions to implement properties in
        // a interface
        PageData MyData
        {get;set;}
// How are we going to input our item
IPageable Input();
        // How do we Output this item
        void Output();
    }
}
